package com.zilator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var held = 0
    private val game = Game()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    private class Btn(val mask: Int, val label: String, val fromRight: Boolean, val ox: Float, val oy: Float, val r: Float)

    private val btns = listOf(
        Btn(In.LEFT, "<", false, 120f, 110f, 62f),
        Btn(In.RIGHT, ">", false, 290f, 110f, 62f),
        Btn(In.JUMP, "^", false, 205f, 255f, 58f),
        Btn(In.BLOCK, "BLOK", false, 450f, 120f, 52f),
        Btn(In.PUNCH, "PUKUL", true, 120f, 130f, 68f),
        Btn(In.KICK, "TENDANG", true, 290f, 100f, 62f),
        Btn(In.SPECIAL, "JURUS", true, 205f, 285f, 58f)
    )

    private val enemyColors = intArrayOf(
        0xFF7E57C2.toInt(), 0xFF26A69A.toInt(), 0xFFEF5350.toInt(), 0xFFEC407A.toInt(), 0xFFFFEE58.toInt()
    )

    init {
        holder.addCallback(this)
    }

    // ---------------- siklus hidup ----------------
    override fun surfaceCreated(h: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {}

    override fun surfaceDestroyed(h: SurfaceHolder) {
        running = false
        try {
            thread?.join()
        } catch (_: InterruptedException) {
        }
        thread = null
    }

    override fun run() {
        val step = 1_000_000_000L / 60
        var last = System.nanoTime()
        var acc = 0L
        while (running) {
            val now = System.nanoTime()
            acc += now - last
            last = now
            if (acc > step * 5) acc = step * 5
            while (acc >= step) {
                game.step(held)
                acc -= step
            }
            try {
                val c = holder.lockCanvas()
                if (c != null) {
                    try {
                        render(c)
                    } finally {
                        holder.unlockCanvasAndPost(c)
                    }
                }
            } catch (_: Exception) {
            }
            try {
                Thread.sleep(2)
            } catch (_: InterruptedException) {
            }
        }
    }

    // ---------------- sentuhan ----------------
    private fun cx(b: Btn, w: Int, u: Float) = if (b.fromRight) w - b.ox * u else b.ox * u
    private fun cy(b: Btn, h: Int, u: Float) = h - b.oy * u

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = width
        val h = height
        val u = h / 720f
        if (e.actionMasked == MotionEvent.ACTION_DOWN) game.advanceRequested = true
        var m = 0
        val up = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        if (!up) {
            for (i in 0 until e.pointerCount) {
                if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                val px = e.getX(i)
                val py = e.getY(i)
                for (b in btns) {
                    val dx = px - cx(b, w, u)
                    val dy = py - cy(b, h, u)
                    if (dx * dx + dy * dy <= (b.r * u * 1.2f).pow(2)) m = m or b.mask
                }
            }
        }
        held = m
        return true
    }

    // ---------------- gambar ----------------
    private fun render(c: Canvas) {
        val w = width
        val h = height
        val u = h / 720f
        val s = min(u, w / 1280f)
        val ox = (w - 1280 * s) / 2f
        val oy = (h - 720 * s) / 2f

        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF140A24.toInt(), 0xFF3A1230.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null

        c.save()
        c.translate(ox, oy)
        c.scale(s, s)
        drawWorld(c)
        c.restore()
        drawControls(c, w, h, u)
    }

    private fun drawWorld(c: Canvas) {
        // bulan
        paint.style = Paint.Style.FILL
        paint.color = 0x55FFF3C4
        c.drawCircle(1010f, 150f, 62f, paint)
        // tiang dojo
        paint.color = 0x33000000
        for (px in intArrayOf(160, 480, 800, 1120)) c.drawRect(px.toFloat(), 120f, px + 22f, Cfg.GROUND.toFloat(), paint)
        // lantai
        paint.color = 0xFF2A1A12.toInt()
        c.drawRect(-2000f, Cfg.GROUND.toFloat(), 3300f, 2800f, paint)
        paint.color = 0xFF5A3A28.toInt()
        c.drawRect(-2000f, Cfg.GROUND.toFloat(), 3300f, Cfg.GROUND + 6f, paint)

        drawFighter(c, game.p1, 0xFFFFA726.toInt())
        drawFighter(c, game.p2, enemyColors[game.opponentIndex.coerceIn(0, enemyColors.size - 1)])

        for (sp in game.sparks) drawSpark(c, sp)
        drawHud(c)
        drawOverlay(c)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t.coerceIn(0f, 1f)

    private fun dark(col: Int) = Color.rgb(
        (Color.red(col) * 0.65f).toInt(), (Color.green(col) * 0.65f).toInt(), (Color.blue(col) * 0.65f).toInt()
    )

    private fun limb(c: Canvas, ox: Float, oy: Float, dir: Int, a1: Float, l1: Float, a2: Float, l2: Float) {
        val r1 = Math.toRadians(a1.toDouble())
        val r2 = Math.toRadians(a2.toDouble())
        val mx = ox + dir * (cos(r1) * l1).toFloat()
        val my = oy + (sin(r1) * l1).toFloat()
        val ex = mx + dir * (cos(r2) * l2).toFloat()
        val ey = my + (sin(r2) * l2).toFloat()
        c.drawLine(ox, oy, mx, my, paint)
        c.drawLine(mx, my, ex, ey, paint)
    }

    private fun drawFighter(c: Canvas, f: Fighter, color: Int) {
        val dir = f.facing
        val fx = f.x.toFloat()
        val feetY = (Cfg.GROUND - f.y).toFloat()

        paint.style = Paint.Style.FILL
        paint.color = 0x55000000
        c.drawOval(fx - 40f, Cfg.GROUND + 4f, fx + 40f, Cfg.GROUND + 18f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 11f
        paint.color = color

        if (f.state == State.KNOCKDOWN || f.state == State.KO) {
            val hipX = fx - dir * 10f
            val hipY = feetY - 16f
            val headX = fx - dir * 95f
            val headY = feetY - 22f
            c.drawLine(hipX, hipY, headX + dir * 20f, headY, paint)
            c.drawLine(hipX, hipY, fx + dir * 70f, feetY - 10f, paint)
            c.drawLine(hipX, hipY - 4f, fx + dir * 55f, feetY - 34f, paint)
            c.drawLine(headX + dir * 20f, headY - 2f, headX + dir * 40f, headY - 28f, paint)
            paint.style = Paint.Style.FILL
            c.drawCircle(headX, headY, 17f, paint)
            return
        }

        var lean = 0f
        var fAU = 50f; var fAF = -50f; var bAU = 70f; var bAF = -40f
        var fLU = 75f; var fLF = 100f; var bLU = 105f; var bLF = 80f
        var bob = sin(game.frame * 0.12f) * 3f
        var aura = false

        val st = if (f.state == State.HITSTUN && f.guarding) State.BLOCK else f.state
        when (st) {
            State.WALK -> {
                val sw = sin(f.stateFrame * 0.35f) * 25f
                fLU = 75f + sw; bLU = 105f - sw; bob = 2f
            }
            State.JUMP -> {
                fLU = 40f; fLF = 110f; bLU = 130f; bLF = 70f
                fAU = -40f; fAF = -70f; bAU = -20f; bAF = -80f; bob = 0f
            }
            State.BLOCK -> {
                fAU = 20f; fAF = -80f; bAU = 30f; bAF = -85f; lean = -4f; bob = 0f
            }
            State.HITSTUN -> {
                lean = -22f; fAU = 120f; fAF = 150f; bAU = 140f; bAF = 170f; bob = 0f
            }
            State.ATTACK -> {
                bob = 0f
                val m = f.move
                if (m != null) {
                    val fr = f.stateFrame
                    val ext = when {
                        fr <= m.startup -> 0.5f * fr / m.startup
                        fr <= m.startup + m.active -> 1f
                        else -> 1f - (fr - m.startup - m.active).toFloat() / m.recovery
                    }
                    when (m) {
                        Moves.P1 -> { fAU = lerp(50f, 0f, ext); fAF = lerp(-50f, 0f, ext); lean = 12f * ext }
                        Moves.P2 -> { bAU = lerp(70f, 0f, ext); bAF = lerp(-40f, 0f, ext); lean = 14f * ext }
                        Moves.P3 -> {
                            fAU = lerp(50f, 0f, ext); fAF = lerp(-50f, 0f, ext)
                            bAU = lerp(70f, 10f, ext); bAF = lerp(-40f, -10f, ext); lean = 25f * ext
                        }
                        Moves.K1 -> { fLU = lerp(75f, -5f, ext); fLF = lerp(100f, 0f, ext); lean = -10f * ext }
                        Moves.K2 -> { fLU = lerp(75f, -40f, ext); fLF = lerp(100f, -25f, ext); lean = -18f * ext }
                        Moves.JURUS -> {
                            fAU = lerp(50f, -5f, ext); fAF = lerp(-50f, -5f, ext)
                            bAU = lerp(70f, 5f, ext); bAF = lerp(-40f, 0f, ext); lean = 22f * ext
                            aura = fr > m.startup && fr <= m.startup + m.active
                        }
                    }
                }
            }
            else -> {}
        }

        val hipX = fx
        val hipY = feetY - 97f + bob
        val neckX = hipX + dir * lean
        val neckY = hipY - 66f
        val headX = neckX + dir * lean * 0.25f
        val headY = neckY - 24f
        val shY = neckY + 8f

        // sisi belakang (lebih gelap)
        paint.color = dark(color)
        limb(c, hipX, hipY, dir, bLU, 50f, bLF, 50f)
        limb(c, neckX, shY, dir, bAU, 42f, bAF, 40f)
        // badan dan sisi depan
        paint.color = color
        c.drawLine(hipX, hipY, neckX, neckY, paint)
        limb(c, hipX, hipY, dir, fLU, 50f, fLF, 50f)
        limb(c, neckX, shY, dir, fAU, 42f, fAF, 40f)
        // kepala + ikat kepala
        paint.style = Paint.Style.FILL
        c.drawCircle(headX, headY, 17f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        paint.color = 0xFFE53935.toInt()
        c.drawLine(headX - 16f, headY - 5f, headX + 16f, headY - 5f, paint)

        if (aura) {
            paint.strokeWidth = 6f
            paint.color = 0xCCFFFFFF.toInt()
            c.drawCircle(neckX + dir * 112f, neckY + 10f, 40f, paint)
            paint.color = 0x66FFA726
            c.drawCircle(neckX + dir * 112f, neckY + 10f, 56f, paint)
        }
    }

    private fun drawSpark(c: Canvas, sp: Spark) {
        val sx = sp.x.toFloat()
        val sy = (Cfg.GROUND - sp.y).toFloat()
        val r = (if (sp.big) 46f else 30f) * (sp.life / (if (sp.big) 12f else 8f) + 0.3f)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 5f
        paint.color = 0xFFFFF59D.toInt()
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(sx + ca * r * 0.4f, sy + sa * r * 0.4f, sx + ca * r, sy + sa * r, paint)
        }
    }

    private fun bar(c: Canvas, x: Float, y: Float, w: Float, h: Float, frac: Float, color: Int, rtl: Boolean) {
        paint.style = Paint.Style.FILL
        paint.color = 0x88000000.toInt()
        c.drawRoundRect(x - 4f, y - 4f, x + w + 4f, y + h + 4f, 8f, 8f, paint)
        paint.color = color
        val fw = w * frac.coerceIn(0f, 1f)
        if (rtl) c.drawRect(x + w - fw, y, x + w, y + h, paint) else c.drawRect(x, y, x + fw, y + h, paint)
    }

    private fun drawHud(c: Canvas) {
        val p1 = game.p1
        val p2 = game.p2
        bar(c, 40f, 36f, 500f, 30f, p1.hp.toFloat() / p1.maxHp, 0xFF66BB6A.toInt(), false)
        bar(c, 740f, 36f, 500f, 30f, p2.hp.toFloat() / p2.maxHp, 0xFFEF5350.toInt(), true)
        bar(c, 40f, 76f, 260f, 12f, p1.energy / Cfg.MAX_EN.toFloat(), 0xFF29B6F6.toInt(), false)
        bar(c, 980f, 76f, 260f, 12f, p2.energy / Cfg.MAX_EN.toFloat(), 0xFF29B6F6.toInt(), true)

        text.color = Color.WHITE
        text.textSize = 28f
        text.textAlign = Paint.Align.LEFT
        c.drawText("KAMU", 44f, 112f, text)
        text.textAlign = Paint.Align.RIGHT
        c.drawText("LAWAN ${game.opponentIndex + 1}", 1236f, 112f, text)
        text.textAlign = Paint.Align.CENTER
        text.textSize = 30f
        c.drawText("${game.opponentIndex + 1} / ${Cfg.OPPONENTS}", 640f, 62f, text)

        if (p1.comboTimer > 0 && p1.comboShown >= 2) {
            text.textSize = 64f
            text.color = 0xFFFFD54F.toInt()
            c.drawText("${p1.comboShown} HIT!", 230f, 230f, text)
        }
        if (p2.comboTimer > 0 && p2.comboShown >= 2) {
            text.textSize = 64f
            text.color = 0xFFFF8A65.toInt()
            c.drawText("${p2.comboShown} HIT!", 1050f, 230f, text)
        }
    }

    private fun drawOverlay(c: Canvas) {
        if (game.phase != Phase.END || game.endTimer < 45) return
        paint.style = Paint.Style.FILL
        paint.color = 0xAA000000.toInt()
        c.drawRect(-2000f, -2000f, 3300f, 2800f, paint)
        text.textAlign = Paint.Align.CENTER
        text.color = Color.WHITE
        text.textSize = 96f
        val title = when {
            game.finishedAll -> "JUARA!"
            game.won -> "MENANG!"
            else -> "KALAH"
        }
        c.drawText(title, 640f, 320f, text)
        text.textSize = 34f
        val sub = when {
            game.finishedAll -> "Semua lawan kalah. Ketuk untuk main lagi"
            game.won -> "Ketuk layar untuk lawan berikutnya"
            else -> "Ketuk layar untuk mengulang dari awal"
        }
        c.drawText(sub, 640f, 390f, text)
    }

    private fun drawControls(c: Canvas, w: Int, h: Int, u: Float) {
        val held = this.held
        for (b in btns) {
            val x = cx(b, w, u)
            val y = cy(b, h, u)
            val r = b.r * u
            val on = (held and b.mask) != 0
            val ready = b.mask == In.SPECIAL && game.p1.energy >= Moves.JURUS.cost
            paint.style = Paint.Style.FILL
            paint.color = if (on) 0x99FFFFFF.toInt() else if (ready) 0x66FFA726 else 0x44FFFFFF
            c.drawCircle(x, y, r, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f * u
            paint.color = if (ready) 0xFFFFA726.toInt() else 0x88FFFFFF.toInt()
            c.drawCircle(x, y, r, paint)
            text.textAlign = Paint.Align.CENTER
            text.color = Color.WHITE
            text.textSize = r * (if (b.label.length > 2) 0.34f else 0.8f)
            c.drawText(b.label, x, y + text.textSize * 0.35f, text)
        }
    }
}
