package com.zilator

class Fighter(var x: Int, var facing: Int, val maxHp: Int) {
    var y = 0            // tinggi dari tanah
    var vx = 0
    var vy = 0
    var hp = maxHp
    var energy = 0
    var state = State.IDLE
    var stateFrame = 0
    var move: Move? = null
    var hasHit = false   // serangan ini sudah mengenai
    var hitstun = 0
    var guarding = false // sedang menahan serangan
    var invuln = 0
    var combo = 0        // combo yang sedang diterima
    var comboShown = 0   // combo yang kita berikan (untuk HUD)
    var comboTimer = 0
    private var prevInput = 0
    private var bufBtn = 0
    private var bufAt = -100

    private fun dirOf(input: Int): Int {
        val l = (input and In.LEFT) != 0
        val r = (input and In.RIGHT) != 0
        return if (l == r) 0 else if (r) 1 else -1
    }

    private fun startMove(m: Move) {
        move = m
        state = State.ATTACK
        stateFrame = 0
        hasHit = false
        vx = 0
        if (m.cost > 0) energy -= m.cost
    }

    fun gain(n: Int) {
        energy = minOf(Cfg.MAX_EN, energy + n)
    }

    private fun canBeHit() = state != State.KNOCKDOWN && state != State.KO && invuln == 0

    fun update(input: Int, opp: Fighter, g: Game) {
        val pressed = input and prevInput.inv()
        prevInput = input
        val btn = when {
            (pressed and In.SPECIAL) != 0 -> In.SPECIAL
            (pressed and In.KICK) != 0 -> In.KICK
            (pressed and In.PUNCH) != 0 -> In.PUNCH
            else -> 0
        }
        if (btn != 0) {
            bufBtn = btn
            bufAt = g.frame
        }
        if (invuln > 0) invuln--
        if (comboTimer > 0) comboTimer--
        val buffered = bufBtn != 0 && g.frame - bufAt <= Cfg.BUFFER

        when (state) {
            State.IDLE, State.WALK, State.BLOCK -> {
                facing = if (opp.x >= x) 1 else -1
                var started = false
                if (buffered) {
                    val m = Moves.chain(null, bufBtn)
                    if (m != null && energy >= m.cost) {
                        startMove(m)
                        bufBtn = 0
                        started = true
                    }
                }
                if (!started) {
                    if ((input and In.JUMP) != 0) {
                        vy = Cfg.JUMP_V
                        vx = dirOf(input) * Cfg.WALK_SPEED
                        y = 1
                        state = State.JUMP
                        stateFrame = 0
                    } else if ((input and In.BLOCK) != 0) {
                        state = State.BLOCK
                        vx = 0
                    } else {
                        val d = dirOf(input)
                        vx = d * Cfg.WALK_SPEED
                        state = if (d != 0) State.WALK else State.IDLE
                    }
                    x += vx
                    stateFrame++
                }
            }

            State.JUMP -> {
                facing = if (opp.x >= x) 1 else -1
                stateFrame++
                x += vx
                y += vy
                vy -= Cfg.GRAVITY
                if (y <= 0) {
                    y = 0
                    vy = 0
                    vx = 0
                    state = State.IDLE
                    stateFrame = 0
                }
            }

            State.ATTACK -> {
                val m = move ?: run {
                    state = State.IDLE
                    return
                }
                stateFrame++
                if (!hasHit && stateFrame > m.startup && stateFrame <= m.startup + m.active) {
                    tryHit(m, opp, g)
                }
                var cancelled = false
                if (hasHit && stateFrame > m.startup && buffered) {
                    val n = Moves.chain(m, bufBtn)
                    if (n != null && energy >= n.cost) {
                        startMove(n)
                        bufBtn = 0
                        cancelled = true
                    }
                }
                if (!cancelled && stateFrame >= m.startup + m.active + m.recovery) {
                    state = State.IDLE
                    move = null
                    stateFrame = 0
                }
            }

            State.HITSTUN -> {
                x += vx
                vx = vx * 3 / 4
                stateFrame++
                hitstun--
                if (hitstun <= 0) {
                    state = State.IDLE
                    guarding = false
                    combo = 0
                    vx = 0
                    stateFrame = 0
                }
            }

            State.KNOCKDOWN -> {
                x += vx
                vx = vx * 4 / 5
                stateFrame++
                if (stateFrame >= Cfg.KD_FRAMES) {
                    state = State.IDLE
                    combo = 0
                    invuln = 20
                    vx = 0
                    stateFrame = 0
                }
            }

            State.KO -> {
                x += vx
                vx = vx * 4 / 5
                stateFrame++
            }
        }
        x = x.coerceIn(Cfg.STAGE_MIN, Cfg.STAGE_MAX)
    }

    private fun tryHit(m: Move, opp: Fighter, g: Game) {
        val a = x + facing * 10
        val b = x + facing * m.reach
        val hx1 = minOf(a, b)
        val hx2 = maxOf(a, b)
        val xOverlap = hx2 >= opp.x - Cfg.HALF && hx1 <= opp.x + Cfg.HALF
        val yOverlap = (y + 150 > opp.y) && (y + 40 < opp.y + Cfg.BODY_H)
        if (xOverlap && yOverlap && opp.canBeHit()) {
            hasHit = true
            opp.takeHit(this, m, g)
        }
    }

    private fun takeHit(att: Fighter, m: Move, g: Game) {
        move = null
        y = 0
        vy = 0
        val blocked = state == State.BLOCK && facing == -att.facing
        if (blocked) {
            hp = maxOf(1, hp - maxOf(1, m.damage / 5))
            vx = att.facing * (m.kbx / 2 + 2)
            state = State.HITSTUN
            guarding = true
            hitstun = 10
            stateFrame = 0
            att.gain(4)
            gain(2)
            g.hitStop = 3
            g.spark((x + att.x) / 2, 90, false)
            return
        }
        val scale = maxOf(30, 100 - 12 * combo)
        hp -= maxOf(1, m.damage * scale / 100)
        combo++
        att.comboShown = combo
        att.comboTimer = 90
        att.gain(10)
        gain(5)
        vx = att.facing * m.kbx
        guarding = false
        stateFrame = 0
        if (hp <= 0) {
            hp = 0
            state = State.KO
            vx = att.facing * 8
            g.hitStop = 10
        } else if (m.knockdown) {
            state = State.KNOCKDOWN
            g.hitStop = 8
        } else {
            state = State.HITSTUN
            hitstun = m.hitstun
            g.hitStop = 5
        }
        g.spark((x + att.x) / 2, 100 + y, m.knockdown)
    }
}
