package com.zilator

/** Semua angka dunia game. Memakai Int agar simulasi deterministik (siap untuk multiplayer). */
object Cfg {
    const val W = 1280
    const val H = 720
    const val GROUND = 600
    const val STAGE_MIN = 70
    const val STAGE_MAX = 1210
    const val HALF = 34          // setengah lebar badan
    const val BODY_H = 170
    const val PUSH = 64          // jarak minimum antar petarung
    const val MAX_HP = 200
    const val MAX_EN = 100
    const val WALK_SPEED = 5
    const val JUMP_V = 22
    const val GRAVITY = 1
    const val BUFFER = 8         // jendela input buffer (frame)
    const val KD_FRAMES = 48     // lama jatuh
    const val OPPONENTS = 5
}

/** Bit tombol. */
object In {
    const val LEFT = 1
    const val RIGHT = 2
    const val JUMP = 4
    const val BLOCK = 8
    const val PUNCH = 16
    const val KICK = 32
    const val SPECIAL = 64
}

enum class State { IDLE, WALK, JUMP, ATTACK, BLOCK, HITSTUN, KNOCKDOWN, KO }

data class Move(
    val name: String,
    val startup: Int,
    val active: Int,
    val recovery: Int,
    val damage: Int,
    val hitstun: Int,
    val kbx: Int,
    val reach: Int,
    val knockdown: Boolean = false,
    val cost: Int = 0
)

object Moves {
    val P1 = Move("Pukul 1", 4, 3, 9, 6, 13, 3, 95)
    val P2 = Move("Pukul 2", 5, 3, 10, 7, 15, 4, 100)
    val P3 = Move("Pukul Berat", 8, 4, 18, 12, 22, 10, 112)
    val K1 = Move("Tendang", 7, 4, 13, 9, 17, 6, 125)
    val K2 = Move("Tendang Putar", 9, 4, 20, 13, 24, 12, 135, knockdown = true)
    val JURUS = Move("Jurus Harimau", 11, 6, 24, 22, 30, 14, 165, knockdown = true, cost = 50)

    /** Rantai combo: dari serangan [cur] dengan tombol [btn] menuju serangan berikutnya. */
    fun chain(cur: Move?, btn: Int): Move? = when (btn) {
        In.SPECIAL -> if (cur == JURUS) null else JURUS
        In.PUNCH -> when (cur) {
            null -> P1
            P1 -> P2
            P2 -> P3
            K1 -> P2
            else -> null
        }
        In.KICK -> when (cur) {
            null -> K1
            P1, P2, K1 -> K2
            else -> null
        }
        else -> null
    }
}
