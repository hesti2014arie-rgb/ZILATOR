package com.zilator

import kotlin.math.abs

/** Lawan komputer. Menghasilkan input yang sama seperti pemain (bitmask In.*). Deterministik. */
class AI(private val level: Int, seed: Int) {
    private var rng = if (seed == 0) 1 else seed
    private var cooldown = 0
    private var holdBlock = 0
    private val queue = ArrayDeque<Int>()

    private val aggression = 25 + 12 * level
    private val blockChance = 5 + 12 * level

    private val basic = listOf(
        intArrayOf(In.PUNCH, In.PUNCH, In.PUNCH),
        intArrayOf(In.PUNCH, In.KICK),
        intArrayOf(In.KICK, In.KICK),
        intArrayOf(In.PUNCH),
        intArrayOf(In.KICK)
    )
    private val withSpecial = basic + listOf(
        intArrayOf(In.PUNCH, In.PUNCH, In.SPECIAL),
        intArrayOf(In.KICK, In.SPECIAL)
    )

    private fun rnd(n: Int): Int {
        rng = rng xor (rng shl 13)
        rng = rng xor (rng ushr 17)
        rng = rng xor (rng shl 5)
        return (rng and 0x7fffffff) % n
    }

    fun next(me: Fighter, foe: Fighter): Int {
        val dist = abs(foe.x - me.x)
        val toward = if (foe.x >= me.x) In.RIGHT else In.LEFT
        val away = if (toward == In.RIGHT) In.LEFT else In.RIGHT
        if (cooldown > 0) cooldown--

        when (me.state) {
            State.HITSTUN, State.KNOCKDOWN, State.KO -> {
                queue.clear()
                holdBlock = 0
                return 0
            }
            State.ATTACK -> {
                // lanjutkan combo hanya jika serangan tadi mengenai
                return if (me.hasHit && queue.isNotEmpty()) queue.removeFirst() else 0
            }
            else -> {}
        }

        if (holdBlock > 0) {
            holdBlock--
            return In.BLOCK
        }
        if (foe.state == State.ATTACK && dist < 200 && rnd(100) < blockChance) {
            holdBlock = 12 + rnd(10)
            return In.BLOCK
        }
        if (dist > 140) {
            if (rnd(300) < 2 + level) return In.JUMP or toward
            return if (rnd(100) < 88) toward else 0
        }
        if (cooldown == 0 && rnd(100) < aggression) {
            val list = if (me.energy >= 50 && level >= 2) withSpecial else basic
            val pattern = list[rnd(list.size)]
            queue.clear()
            for (i in 1 until pattern.size) queue.addLast(pattern[i])
            cooldown = 25 + rnd(70 - level * 10)
            return pattern[0]
        }
        if (dist < 85 && rnd(100) < 35) return away
        return 0
    }
}
