package com.zilator

import kotlin.math.abs

enum class Phase { FIGHT, END }

class Spark(val x: Int, val y: Int, var life: Int, val big: Boolean)

class Game {
    var frame = 0
    var opponentIndex = 0
    var p1 = Fighter(380, 1, Cfg.MAX_HP)
    var p2 = Fighter(900, -1, Cfg.MAX_HP)
    private var ai = AI(0, 1)
    var phase = Phase.FIGHT
    var endTimer = 0
    var won = false
    var finishedAll = false
    var hitStop = 0
    val sparks = ArrayList<Spark>()

    @Volatile
    var advanceRequested = false

    init {
        reset(0)
    }

    fun reset(level: Int) {
        frame = 0
        opponentIndex = level
        p1 = Fighter(380, 1, Cfg.MAX_HP)
        p2 = Fighter(900, -1, Cfg.MAX_HP + 20 * level)
        ai = AI(level, 9871 + level * 131)
        phase = Phase.FIGHT
        endTimer = 0
        won = false
        finishedAll = false
        hitStop = 0
        sparks.clear()
    }

    fun spark(x: Int, y: Int, big: Boolean) {
        sparks.add(Spark(x, y, if (big) 12 else 8, big))
    }

    private fun doAdvance() {
        if (phase != Phase.END || endTimer < 45) return
        if (won && opponentIndex < Cfg.OPPONENTS - 1) reset(opponentIndex + 1) else reset(0)
    }

    /** Satu langkah simulasi (60 kali per detik). in1 = input pemain. */
    fun step(in1: Int) {
        if (advanceRequested) {
            advanceRequested = false
            doAdvance()
        }
        frame++
        val it = sparks.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.life--
            if (s.life <= 0) it.remove()
        }
        if (hitStop > 0) {
            hitStop--
            return
        }
        val fighting = phase == Phase.FIGHT
        val i1 = if (fighting) in1 else 0
        val i2 = if (fighting) ai.next(p2, p1) else 0
        p1.update(i1, p2, this)
        p2.update(i2, p1, this)
        separate()

        if (phase == Phase.FIGHT && (p1.state == State.KO || p2.state == State.KO)) {
            phase = Phase.END
            won = p2.state == State.KO
            finishedAll = won && opponentIndex == Cfg.OPPONENTS - 1
            endTimer = 0
        }
        if (phase == Phase.END) endTimer++
    }

    private fun separate() {
        if (p1.y > 0 || p2.y > 0) return
        val dx = p2.x - p1.x
        val overlap = Cfg.PUSH - abs(dx)
        if (overlap > 0) {
            val sign = if (dx >= 0) 1 else -1
            val half = overlap / 2
            p1.x -= sign * half
            p2.x += sign * (overlap - half)
            p1.x = p1.x.coerceIn(Cfg.STAGE_MIN, Cfg.STAGE_MAX)
            p2.x = p2.x.coerceIn(Cfg.STAGE_MIN, Cfg.STAGE_MAX)
        }
    }
}
