# ZILATOR (prototipe)

Game fight silat 2D untuk Android (Kotlin, tanpa mesin game). Prototipe tahap 1-4:
loop game, petarung rangka, serangan + hitbox, combo + jurus, dan lawan AI.

## Kontrol (landscape)
- Kiri: **<** **>** jalan, **^** lompat, **BLOK** menahan serangan
- Kanan: **PUKUL**, **TENDANG**, **JURUS** (butuh energi 50, menyala jika siap)

## Combo
- Pukul → Pukul → Pukul (Pukul Berat)
- Pukul → Tendang (Tendang Putar, menjatuhkan)
- Tendang → Pukul → Pukul
- Serangan apa pun yang mengenai bisa disambung ke **JURUS**
- Tombol yang ditekan sedikit lebih awal tetap terbaca (input buffer)
- Combo hanya tersambung jika serangan sebelumnya mengenai lawan

## Struktur
| File | Isi |
|---|---|
| `Config.kt` | konstanta, bit tombol, data gerakan, rantai combo |
| `Fighter.kt` | mesin status petarung, hitbox, damage, combo |
| `Game.kt` | simulasi 60 Hz deterministik, ronde, lawan ke-1 sampai 5 |
| `AI.kt` | lawan komputer (agresi dan blok naik per level) |
| `GameView.kt` | gambar rangka, HUD, kontrol sentuh |

Simulasi memakai bilangan bulat dan langkah tetap 60 Hz supaya siap untuk multiplayer (tahap berikutnya).

## Build
Upload folder atau zip ini ke GitHub. Workflow `.github/workflows/main.yml` menghasilkan
`ZILATOR-Proto.apk` di tab Actions, bagian Artifacts.

Nama ZILATOR dipakai sebagai nama kerja. Semua karakter dan gambar di sini orisinal.
